# Copyright Amazon.com Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.

"""Provides utilities for working with quantum information concepts. It
includes classes for representing and manipulating tensor products and weighted
sums of Pauli operators.
"""

from braket.quantum_information.pauli_string import PauliString  # ruff:ignore[unused-import]
from braket.quantum_information.pauli_sum import (  # ruff:ignore[unused-import]
    PauliStringSum,
    PauliSum,
)
