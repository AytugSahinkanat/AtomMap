# Copyright Amazon.com Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.

"""Provides classes for representing and working with qubits. It provides
Qubit for individual qubit indices and QubitSet for ordered collections of qubits
used in quantum operations.
"""

from braket.registers.qubit import Qubit, QubitInput  # ruff:ignore[unused-import]
from braket.registers.qubit_set import QubitSet, QubitSetInput  # ruff:ignore[unused-import]
