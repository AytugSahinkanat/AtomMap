# Copyright Amazon.com Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.

"""In Amazon Braket, the atomic request to a device is a quantum task. For gate-based
devices, this request includes the quantum circuit, measurement instructions, and
shot count. This module provides result types for gate-based circuits, analog
Hamiltonian simulations, and program sets, along with QuantumTask and
QuantumTaskBatch for tracking execution and launching multiple tasks in parallel,
and LocalQuantumTask and LocalQuantumTaskBatch for local simulation results.
"""

from braket.tasks import _jupyter_setup  # ruff:ignore[unused-import]
from braket.tasks.analog_hamiltonian_simulation_quantum_task_result import (  # ruff:ignore[unused-import]
    AnalogHamiltonianSimulationQuantumTaskResult,
    AnalogHamiltonianSimulationShotStatus,
)
from braket.tasks.annealing_quantum_task_result import (
    AnnealingQuantumTaskResult,  # ruff:ignore[unused-import]
)
from braket.tasks.gate_model_quantum_task_result import (
    GateModelQuantumTaskResult,  # ruff:ignore[unused-import]
)
from braket.tasks.photonic_model_quantum_task_result import (
    PhotonicModelQuantumTaskResult,  # ruff:ignore[unused-import]
)
from braket.tasks.program_set_quantum_task_result import (
    ProgramSetQuantumTaskResult,  # ruff:ignore[unused-import]
)
from braket.tasks.quantum_task import QuantumTask  # ruff:ignore[unused-import]
from braket.tasks.quantum_task_batch import QuantumTaskBatch  # ruff:ignore[unused-import]
