# Copyright Amazon.com Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.

"""Quantum error mitigation is a set of techniques aimed at reducing the effects
of errors in quantum computers. This module provides ErrorMitigation base class
and Debias for debiasing, which maps a circuit into multiple variants to reduce
the effect of systematic errors.
"""

from braket.error_mitigation.debias import Debias  # ruff:ignore[unused-import]
from braket.error_mitigation.error_mitigation import ErrorMitigation  # ruff:ignore[unused-import]
