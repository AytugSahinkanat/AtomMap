# Copyright Amazon.com Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.

from __future__ import annotations

from collections.abc import Sequence

import numpy as np

from braket.default_simulator.observables import Hermitian, Identity, TensorProduct
from braket.default_simulator.operation import GateOperation, KrausOperation
from braket.default_simulator.result_types import _from_braket_observable
from braket.ir.jaqcd.program_v1 import Results
from braket.ir.jaqcd.shared_models import Observable, OptionalMultiTarget


class ClassicalRegister:
    """A named classical bit register that measurements are recorded into.

    Args:
        name (str | None): The program-level name of the register, or ``None``
            for the anonymous register that collects measurements without a
            classical destination.
        size (int): Number of elements.
        order (int): Position of the register in declaration order. ``-1`` for
            a register that is not part of the circuit, such as a feedback bit.

    Attributes:
        sources (list[int | None]): The qubit measured into each element, or
            ``None`` if the element holds no measurement.
        overwritten (set[int]): Elements whose end-of-circuit measurement was
            classically written afterwards, so the written value is reported
            instead of the sampled bit. Only set when pending measurements are
            flushed. Branched paths keep the written value in their variables
            instead.
    """

    def __init__(self, name: str | None, size: int, order: int):
        self.name = name
        self.order = order
        self.sources: list[int | None] = [None] * size
        self.overwritten: set[int] = set()

    @property
    def size(self) -> int:
        return len(self.sources)

    @property
    def measured(self) -> bool:
        """Whether any element holds a measurement."""
        return any(source is not None for source in self.sources)

    def bind(self, element: int, qubit: int) -> None:
        """Record ``qubit`` as the measurement source of ``element``.

        Simulator samples qubits at the end of the circuit, so registers must
        know mapping to retrieve the measurement results. A new measurement
        replaces any earlier classical write, so ``element`` is no longer
        overwritten.
        """
        if not 0 <= element < self.size:
            raise IndexError(
                f"Classical register index {element} out of range for "
                f"register of length {self.size} `{self.name}`."
            )
        self.sources[element] = qubit
        self.overwritten.discard(element)

    def grow(self, count: int) -> None:
        """Append ``count`` unbound elements to the register.

        Only the anonymous register grows: it has no declared size and gains one
        element per qubit each time a destination-less ``measure`` is recorded.
        """
        self.sources.extend([None] * count)

    def __repr__(self) -> str:
        return f"ClassicalRegister(name={self.name!r}, size={self.size}, sources={self.sources})"


class Circuit:
    """
    This is a lightweight analog to braket.ir.jaqcd.program_v1.Program.
    The Interpreter compiles to an IR to hand off to the simulator,
    braket.default_simulator.state_vector_simulator.StateVectorSimulator, for example.
    Our simulator module takes in a circuit specification that satisfies the interface
    implemented by this class.
    """

    def __init__(
        self,
        instructions: list[GateOperation] | None = None,
        results: list[Results] | None = None,
    ):
        self.instructions = []
        self.results = []
        self.qubit_set = set()
        self.classical_registers: list[ClassicalRegister] = []
        self._anonymous_register: ClassicalRegister | None = None

        if instructions:
            for instruction in instructions:
                self.add_instruction(instruction)

        if results:
            for result in results:
                self.add_result(result)

    def add_instruction(self, instruction: GateOperation | KrausOperation) -> None:
        """
        Add instruction to the circuit.

        Args:
            instruction (GateOperation): Instruction to add.
        """
        self.instructions.append(instruction)
        self.qubit_set |= set(instruction.targets)

    def declare_register(self, name: str | None, size: int) -> ClassicalRegister:
        """Declare a classical register and append it in declaration order.

        Args:
            name (str | None): The program-level name of the register, or ``None``
                for the anonymous register.
            size (int): Number of elements.

        Returns:
            ClassicalRegister: The new register handle.
        """
        register = ClassicalRegister(name, size, order=len(self.classical_registers))
        self.classical_registers.append(register)
        return register

    def anonymous_register(self) -> ClassicalRegister:
        """The register that collects measurements without a classical destination.

        Created (and placed in declaration order) on first use.
        """
        if self._anonymous_register is None:
            self._anonymous_register = self.declare_register(None, 0)
        return self._anonymous_register

    def add_measure(
        self,
        target: tuple[int, ...],
        register: ClassicalRegister | None = None,
        register_indices: Sequence[int] | None = None,
    ) -> list[tuple[ClassicalRegister, int]]:
        """Record the measurement of ``target`` into a classical register.

        Args:
            target (tuple[int, ...]): The qubits measured, in order.
            register (ClassicalRegister | None): The destination register. ``None``
                appends one new element per qubit to the anonymous register.
            register_indices (Sequence[int] | None): The destination index within
                ``register`` for each qubit, aligned with ``target``. Defaults to
                ``range(len(target))``, i.e. the whole register. Ignored when
                ``register`` is ``None``.

        Returns:
            list[tuple[ClassicalRegister, int]]: The ``(register, register_index)``
            each qubit was bound to, in ``target`` order.
        """
        if register is None:
            register = self.anonymous_register()
            first = register.size
            register.grow(len(target))
            register_indices = range(first, first + len(target))
        elif register_indices is None:
            register_indices = range(len(target))
        elif len(register_indices) != len(target):
            raise ValueError(
                "Expected one register index per measured qubit, but got "
                f"{len(register_indices)} register indices for {len(target)} qubits."
            )
        bound = []
        for qubit, register_index in zip(target, register_indices):
            register.bind(register_index, qubit)
            self.qubit_set.add(qubit)
            bound.append((register, register_index))
        return bound

    @property
    def measurement_slots(self) -> list[tuple[ClassicalRegister, int, int]]:
        """``(register, element, qubit)`` for every measured register element."""
        return [
            (register, element, qubit)
            for register in self.classical_registers
            for element, qubit in enumerate(register.sources)
            if qubit is not None
        ]

    @property
    def measured_qubits(self) -> list[int]:
        """The measured qubit of each measurement slot, in ``measurement_slots`` order."""
        return [qubit for _, _, qubit in self.measurement_slots]

    @property
    def measured_registers(self) -> list[ClassicalRegister]:
        """The registers holding at least one measurement, in declaration order."""
        return [register for register in self.classical_registers if register.measured]

    def reported_measurement_slots(self) -> list[tuple[ClassicalRegister, int, int]]:
        """The measurement slots sampled for the result.

        Measurements without a destination are left out when any named register is
        measured. When no named register is measured, they are the slots returned.
        For a program with outputs, the sampled rows are used to compute the outputs
        rather than being reported as ``measurements``.

        Returns:
            list[tuple[ClassicalRegister, int, int]]: ``(register, element, qubit)``
            for each sampled slot, in ``measurement_slots`` order. Empty if nothing
            was measured.
        """
        slots = self.measurement_slots
        named = [slot for slot in slots if slot[0] is not self._anonymous_register]
        return named or slots

    def validate_single_measured_register(self) -> None:
        """Reject programs without outputs whose measurements span more than one
        named register. Measurements without a destination do not count.

        Raises:
            ValueError: If measurements were recorded into more than one named register.
        """
        measured = [
            register
            for register in self.measured_registers
            if register is not self._anonymous_register
        ]
        if len(measured) > 1:
            names = ", ".join(f"`{register.name}`" for register in measured)
            raise ValueError(
                f"Measurements were recorded into {len(measured)} classical registers: "
                f"{names}. Measure into a single register, or declare the values to "
                "return with `output`, e.g. `output bit[2] c;`."
            )

    def add_result(self, result: Results) -> None:
        """
        Add result type to the circuit.

        Args:
            result (Results): Result type to add.
        """
        self.results.append(result)
        if isinstance(result, OptionalMultiTarget) and result.targets is not None:
            self.qubit_set |= set(result.targets)

    @property
    def num_qubits(self) -> int:
        return len(self.qubit_set)

    @property
    def basis_rotation_instructions(self):
        """Basis rotation instructions implied by the provided observables"""
        basis_rotation_instructions = []
        observable_map = {}

        def process_observable(observable):
            if isinstance(observable, Identity):
                return
            measured_qubits = tuple(observable.measured_qubits)
            for qubit in measured_qubits:
                for target, previously_measured in observable_map.items():
                    if qubit in target:
                        # must ensure that target is the same
                        if target != measured_qubits:
                            raise ValueError("Qubit part of incompatible results targets")
                        # must ensure observable is the same
                        if type(previously_measured) is not type(observable):
                            raise ValueError("Conflicting result types applied to a single qubit")
                        # including matrix value for Hermitians
                        if isinstance(observable, Hermitian) and not np.allclose(
                            previously_measured.matrix, observable.matrix
                        ):
                            raise ValueError("Conflicting result types applied to a single qubit")
            observable_map[measured_qubits] = observable

        for result in self.results:
            if isinstance(result, Observable):
                observables = result.observable

                if result.targets is not None:
                    braket_obs = _from_braket_observable(observables, result.targets)

                    if isinstance(braket_obs, TensorProduct):
                        for factor in braket_obs.factors:
                            process_observable(factor)
                    else:
                        process_observable(braket_obs)

                else:
                    for q in range(self.num_qubits):
                        braket_obs = _from_braket_observable(observables, [q])
                        process_observable(braket_obs)

        for obs in observable_map.values():
            diagonalizing_gates = obs.diagonalizing_gates(self.num_qubits)
            basis_rotation_instructions.extend(diagonalizing_gates)

        return basis_rotation_instructions

    def __eq__(self, other: Circuit):
        return (self.instructions, self.results) == (other.instructions, other.results)
